package com.cg.spring.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name="customerDetails")
public class Customer{
	
	@Id
	@Column(length=10, unique=true, nullable=false)
	private String mobileNo;
	@Column(length=30)
	private String name;
	@Column(length=2)
	private int age;
	@Column(length=30)
	private String emailId;
	@Column(length=8)
	private String gender;
	@Column(length=30)
	private double balance;
	@Lob
	private String transaction;

	public Customer() {
	}
	
	public Customer(String name, int age, String emailId, String gender, String mobileNo,
			double balance, String transaction) {
		super();
		this.name = name;
		this.age = age;
		this.emailId = emailId;
		this.gender = gender;
		this.mobileNo = mobileNo;
		this.balance = balance;
		this.transaction = transaction;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
}

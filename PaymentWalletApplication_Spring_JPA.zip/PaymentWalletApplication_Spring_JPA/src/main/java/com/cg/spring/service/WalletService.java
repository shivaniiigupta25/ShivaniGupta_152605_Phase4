package com.cg.spring.service;

import java.util.List;

import com.cg.spring.dto.Customer;

public interface WalletService {

	public void createAccount(Customer customerBean);

	public List<Customer> showAllCustomers();

	public double showBalance(String custContact);

	public void withdrawAmount(String custContact, double withdrawAmt);

	public void depositAmount(String custContact, double depositAmt);

	public void fundTransfer(String senderCont, String receiverCont, double custAmt);

	public String printTransactions(String custContact);
}
